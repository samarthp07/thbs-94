package com.torryharris.mvcdemo.app;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.torryharris.mvcdemo.config.MVCConfig;
import com.torryharris.mvcdemo.model.User;
import com.torryharris.mvcdemo.service.UserDaoService;

public class UserJPA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ApplicationContext context = new AnnotationConfigApplicationContext(MVCConfig.class);

		UserDaoService userService = context.getBean(UserDaoService.class);
		
		User u1 = new User("abc","abc@gmail.com",4679,"uuuug",23,"thfhgbv");
		//Person p2 = new Person(89686L,"Lakshman","Ayodhya",87954735L);
		
		ArrayList<User> userList = new ArrayList<User>();
	userList.add(u1);
	
		
		
		
		for(User p : userList) {
			userService.insertuser(p);
		}
		System.out.println("inserted");
		
		
		
		
	}

	}


