package com.torryharris.mvcdemo.service;

import java.util.List;

import com.torryharris.mvcdemo.model.User;

public interface UserDaoService {
	
void insertuser(User user);
	
	List<User> getAllPerson();

}
