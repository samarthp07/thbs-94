package com.torryharris.mvcdemo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.torryharris.mvcdemo.model.Product;
import com.torryharris.mvcdemo.model.User;
import com.torryharris.mvcdemo.service.ProductService;


@Controller
public class MVCController {
	
	@Autowired
	private ProductService productService;
	
	private static ArrayList<User> userList;
	private static ArrayList<Product> productList;
	
	
	static {
		userList= new ArrayList<User>();
		
		
		
	}
static {
	productList = new ArrayList<Product>();
	//	ArrayList<Product> productList1=(ArrayList<Product>) ProductService.getAllProduct();
		
}
	
	
	@RequestMapping("/login")
	public ModelAndView login(@RequestParam("username") String username, @RequestParam("password") String password) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("response.jsp");
		boolean userAuthenticated=false;
		for(User user: userList) {
		if(username.equals(user.getUserName()) && password.equals(user.getPassword())) {
			userAuthenticated=true;
			mv.addObject("username", username);
			break;
			}
		}
		mv.addObject("status", userAuthenticated);
		return mv;
	}
	
	@PostMapping("/register")
	public ModelAndView register(@RequestParam("user") String userName,@RequestParam("email") String email,
			@RequestParam("phone") long phone,@RequestParam("address") String address,
			@RequestParam("age") int age,@RequestParam("password1") String password) {
	
		User user = new User(userName, email, phone, address, age, password);
		userList.add(user);
		System.out.println(user);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("reg_success.jsp");
		mv.addObject("username",userName);
		return mv;
				
	}
	@PostMapping("/product")
	public ModelAndView product(@RequestParam("id") int id,@RequestParam("productCategory") String productCategory,
			@RequestParam("productDescription") String productDescription,@RequestParam("productManufacturer") String productManufacturer ,
			@RequestParam("productName") String productName,@RequestParam("productPrice") int productPrice,@RequestParam("unitStock") String UnitStock)  {
	
		Product p = new Product(id,productCategory,productDescription,productManufacturer,productName,productPrice,UnitStock);
		productList.add(p);
		System.out.println(p);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("productup.jsp");
		mv.addObject("id",id);
		return mv;
				
	}
	

}
