package com.torryharris.mvcdemo.repository;

import java.util.List;

//import com.torryharris.SpringJPADemo.model.Person;
import com.torryharris.mvcdemo.model.User;

public interface UserDao {
	
	void insertuser(User user);
	
	List<User> getAllPerson();


}
