package com.torryharris.mvcdemo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.torryharris.mvcdemo.model.Product;
@Repository
public class ProductImpl implements ProductDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional

	public void insertProduct(Product product) {
		// TODO Auto-generated method stub
		entityManager.persist(product);
		
		
	}

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Product> cq = builder.createQuery(Product.class);
		Root<Product> root = cq.from(Product.class);
		cq.select(root);
		return entityManager.createQuery(cq).getResultList();
		
	}

}
